#ifndef SPINE_T
#define SPINE_T

#include <cgraph.h>

void genSpine (Agraph_t * g, float sparse_ratio, int verbose);

#endif
